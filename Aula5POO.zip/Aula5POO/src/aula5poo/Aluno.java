package aula5poo;

import javax.swing.JOptionPane;

public class Aluno {
    
   private String nome;
    private String rgm;
    private int idade;
    private float peso;
    private float altura;
    private float mediaNotas;

    public Aluno() {
    }

    public Aluno(String nome, String rgm, int idade, float peso, float altura, float mediaNotas) {
        this.nome = nome;
        this.rgm = rgm;
        this.idade = idade;
        this.peso = peso;
        this.altura = altura;
        this.mediaNotas = mediaNotas;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRgm() {
        return rgm;
    }

    public void setRgm(String rgm) {
        this.rgm = rgm;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public float getMediaNotas() {
        return mediaNotas;
    }

    public void setMediaNotas(float mediaNotas) {
        this.mediaNotas = mediaNotas;
    }

    @Override
    public String toString() {
        return "Aluno{" + "nome=" + nome + ", rgm=" + rgm + ", idade=" + idade + ", peso=" + peso + ", altura=" + altura + ", mediaNotas=" + mediaNotas + '}';
    }
    
    public static void main(String[] args){
        Aluno objAluno = new Aluno("Bruna", "51651", 22, 55f, 1.65f, 5f);
        
        int cont = 0;
        float soma = 0;
        while(cont < 4) {
            float nota  = Float.parseFloat(JOptionPane.showInputDialog(null, "Nota", "Insira a nota: ", JOptionPane.INFORMATION_MESSAGE));
            soma += nota;
            cont++;
        }
        objAluno.setMediaNotas((soma/4));
        System.out.println("A média é " + objAluno.getMediaNotas()); 
   }
}